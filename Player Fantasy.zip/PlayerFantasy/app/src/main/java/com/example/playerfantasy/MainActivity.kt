package com.example.playerfantasy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.playerfantasy.screens.CharacterSheetsScreen
import com.example.playerfantasy.screens.CreateCharacterSheetScreen
import com.example.playerfantasy.screens.DiceRollerScreen
import com.example.playerfantasy.screens.SearchScreen
import com.example.playerfantasy.ui.theme.PlayerFantasyTheme
import com.example.playerfantasy.viewmodel.SearchViewModel

//Steven Formisano
//Project 21B- Final Project
//2/29/24
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PlayerFantasyTheme {
                val navController = rememberNavController()
                Surface(color = MaterialTheme.colorScheme.background) {
                    NavHost(navController = navController, startDestination = "mainMenu") {
                        // Main menu destination
                        composable("mainMenu") {
                            MainMenu(navController)
                        }
                        // Other destinations
                        composable("diceRollerScreen") {
                            DiceRollerScreen(navController)
                        }
                        composable("characterSheetsScreen") {
                            CharacterSheetsScreen(navController)
                        }
                        composable("createCharacterSheetScreen") {
                            CreateCharacterSheetScreen(navController)
                        }
                        // Search screen destination
                        composable("searchScreen") {
                            // Obtain SearchViewModel instance specific to this NavGraph
                            val searchViewModel: SearchViewModel = viewModel()

                            // Pass both searchViewModel and navController to SearchScreen
                            SearchScreen(searchViewModel, navController)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MainMenu(navController: NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Banner at the very top
        Box(
            modifier = Modifier
                .fillMaxWidth() // Ensure the Box fills the width
                .padding(bottom = 16.dp) // Add some padding below the banner
                .background(Color(0xFF003049)), // Set the background color of the banner
            contentAlignment = Alignment.Center // Center the content (text) within the Box
        ) {
            Text(
                text = "Created By Steven Form.",
                style = MaterialTheme.typography.bodyLarge.copy(color = Color.White),
                modifier = Modifier.padding(vertical = 8.dp) // Add padding inside the Box for the Text
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        // The rest of your buttons with custom styling
        CustomButton(text = "View Character Sheets") {
            navController.navigate("characterSheetsScreen")
        }

        CustomButton(text = "DnD Search Screen") {
            navController.navigate("searchScreen")
        }

        CustomButton(text = "Create Custom Character Sheet") {
            navController.navigate("createCharacterSheetScreen")
        }

        CustomButton(text = "Dice Roller") {
            navController.navigate("diceRollerScreen")
        }
    }
}

@Composable
fun CustomButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        // Apply the custom color and make the button rounded
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003049)),
        shape = RoundedCornerShape(50), // Apply rounded corners
        modifier = Modifier.padding(vertical = 18.dp) // Add some vertical padding between buttons
    ) {
        Text(
            text = text,
            color = Color.White // Set the text color to white
        )
    }
}

@Preview(showBackground = true)
@Composable
fun MainMenuPreview() {
    val navController = rememberNavController()
    PlayerFantasyTheme {
        MainMenu(navController)
    }
}