package com.example.playerfantasy.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
// removed for other pages do the same thing as it.
@Composable
fun LoadSaveCharacterSheetScreen() {
    Column {
        Text(text = "Load and Save Character Sheets")
        // Add more UI elements as needed
    }
}