package com.example.playerfantasy.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.playerfantasy.models.CharacterSheet

@Dao
interface CharacterSheetDao {
    @Query("SELECT * FROM CharacterSheet")
    fun getAllCharacterSheets(): LiveData<List<CharacterSheet>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCharacterSheet(sheet: CharacterSheet)
}